package com.cs360.maryeakins_inventory.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class LoginHelper extends SQLiteOpenHelper{

    public static final String DATABASE = "loginDb";

    public LoginHelper(@Nullable Context context){super(context, "loginDb", null, 1);}

    // create new table
    @Override
    public void onCreate(SQLiteDatabase appDatabase) {
        appDatabase.execSQL("create Table users(username TEXT primary key, password TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase appDatabase, int i, int i1) {
        appDatabase.execSQL("drop Table if exists users");
    }

    // add a new user to the table
    public Boolean insertData(String userName, String passWord) {
        SQLiteDatabase appDatabase = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("username", userName);
        contentValues.put("password", passWord);
        long result = appDatabase.insert("users", null, contentValues);
        if (result == -1) return false;
        else
            return true;

    }

    public Boolean findUsername(String username) {
        SQLiteDatabase appDatabase = this.getWritableDatabase();

        Cursor cursor = appDatabase.rawQuery("Select * from users where username = ?", new String[] {username});
        if (cursor.getCount() > 0)
            return true;
        else
            return false;
    }

    public Boolean checkUsernamePassword(String username, String password) {
        SQLiteDatabase appDatabase = this.getWritableDatabase();

        Cursor cursor = appDatabase.rawQuery("Select * from users where username = ? and password = ?", new String[] {username, password});
        if(cursor.getCount() > 0)
            return true;
        else
            return false;
    }




}

