package com.cs360.maryeakins_inventory;

public class Util {
    public static final int DATABASE_VERSION = 1;
    public static final String DATABASE_NAME = "inventory_db";
    public static final String TABLE_NAME = "items";

    // Items table column names
    public static final String KEY_ID = "id";
    public static final String KEY_NAME = "item_name";
    public static final String KEY_DESC = "item_desc";

    public static final String KEY_QTY = "item_quantity";
}

