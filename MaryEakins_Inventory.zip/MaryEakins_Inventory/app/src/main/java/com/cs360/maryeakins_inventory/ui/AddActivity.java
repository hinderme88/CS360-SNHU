package com.cs360.maryeakins_inventory.ui;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import com.cs360.maryeakins_inventory.R;
import com.cs360.maryeakins_inventory.data.DatabaseHelper;
import com.cs360.maryeakins_inventory.model.Item;

public class AddActivity extends AppCompatActivity {

    private EditText addItemName, addItemDesc, addItemQty;

    private DatabaseHelper DB;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        DB = new DatabaseHelper(this);

        addItemName = findViewById(R.id.addNameEdit);
        addItemDesc = findViewById(R.id.addDescEdit);
        addItemQty = findViewById(R.id.addQtyEdit);

        Button addButton = findViewById(R.id.addItemButton);

        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addItem();
            }
        });


    }
    private void addItem() {
        String itemName = addItemName.getText().toString();
        String itemDesc = addItemDesc.getText().toString();
        int itemQty;
        try {
            itemQty = Integer.parseInt(addItemQty.getText().toString());
        } catch (NumberFormatException e) {
            return;
        }
        // add item to database
        Item item = new Item(itemName, itemDesc, itemQty);

        Boolean checkItemName = DB.checkItemUnique(itemName);

        if (checkItemName == true) {
            DB.updateItem(item);
            Toast.makeText(AddActivity.this, "Item name already in use.", Toast.LENGTH_SHORT).show();
        } else {
            Boolean itemAdded = DB.addItem(item);
            if (itemAdded == true) {
                // User was added, proceed to main page of app
                Toast.makeText(AddActivity.this, "Item added successfully.", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(AddActivity.this, "Unable to add item.", Toast.LENGTH_SHORT).show();

            }
            finish();
        }
    }
}