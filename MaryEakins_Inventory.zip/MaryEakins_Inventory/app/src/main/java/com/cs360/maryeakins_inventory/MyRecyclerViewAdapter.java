package com.cs360.maryeakins_inventory;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.cs360.maryeakins_inventory.model.Item;

import java.util.List;

public class MyRecyclerViewAdapter extends RecyclerView.Adapter<MyRecyclerViewAdapter.ViewHolder> {

    private List<Item> itemList;
    private Context context;
    private OnItemClickListener onItemClickListener;
    private OnItemDeleteListener onItemDeleteListener;

    // data is passed into the constructor
    public MyRecyclerViewAdapter(List<Item> items, Context context,  OnItemClickListener onItemClickListener, OnItemDeleteListener onItemDeleteListener) {
        itemList = items;
        this.context = context;
        this.onItemClickListener = onItemClickListener;
        this.onItemDeleteListener = onItemDeleteListener;
    }

    // inflates the row layout from xml when needed
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.recycler_view_row, parent, false);
        return new ViewHolder(view, onItemClickListener, onItemDeleteListener);
    }

    // binds the data to the TextView in each row
    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        Item item = itemList.get(holder.getAdapterPosition());
        holder.itemName.setText(item.getItem_name());
        holder.itemDesc.setText(item.getItem_desc());
        holder.itemQty.setText(String.valueOf(item.getItem_qty()));

        holder.buttonEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (onItemClickListener != null) {
                    onItemClickListener.onItemClick(item);
                }
            }
        });

        // set up the delete button
        holder.buttonDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (onItemDeleteListener != null) {
                    onItemDeleteListener.onItemDelete(item, holder.getAdapterPosition());
                }
            }
        });

    }

    // total number of rows
    @Override
    public int getItemCount() {
        return itemList.size();
    }


    // stores and recycles views as they are scrolled off screen
    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        OnItemClickListener onItemClickListener;
        OnItemDeleteListener onItemDeleteListener;
        private Item item;
        TextView itemName, itemDesc, itemQty;
        ImageButton buttonEdit, buttonDelete;

        public ViewHolder(View itemView, OnItemClickListener onItemClickListener, OnItemDeleteListener onItemDeleteListener) {
            super(itemView);
            itemName = itemView.findViewById(R.id.rowNameEdit);
            itemQty = itemView.findViewById(R.id.rowQtyEdit);
            itemDesc = itemView.findViewById(R.id.rowDescEdit);
            buttonEdit = itemView.findViewById(R.id.rowEditBtn);
            buttonDelete = itemView.findViewById(R.id.rowDeleteBtn);
            this.onItemClickListener = onItemClickListener;
            this.onItemDeleteListener = onItemDeleteListener;
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            int position = getAdapterPosition();
            if (position != RecyclerView.NO_POSITION && onItemClickListener != null) {
                onItemClickListener.onItemClick(itemList.get(position));
            }
        }
    }

    public interface OnItemClickListener {
        void onItemClick(Item item);

    }

    public interface OnItemDeleteListener {
        void onItemDelete(Item item, int position);
    }

    // remove an item
    public void removeItem(int position) {
        itemList.remove(position);
        notifyItemRangeChanged(position, itemList.size());
    }


}