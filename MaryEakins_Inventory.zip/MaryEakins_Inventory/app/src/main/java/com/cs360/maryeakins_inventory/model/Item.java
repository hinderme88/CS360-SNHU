package com.cs360.maryeakins_inventory.model;


public class Item {

    private long item_id;
    private String item_name;
    private String item_desc;
    private int item_qty;

    public Item() {

    }

    public Item(long id, String name) {
        item_id = id;
        item_name = name;
        item_qty = 0;

    }

    public Item(long id, String name, int quantity) {
        item_id = id;
        item_name = name;
        item_qty = quantity;
    }
    public Item(String name, String desc, int quantity) {
        item_name = name;
        item_desc = desc;
        item_qty = quantity;
    }

    public long getId() {
        return item_id;
    }

    public void setId(long id) {
        this.item_id = id;
    }
    public String getItem_name() {return item_name;}

    public void setItem_name(String name) {
        item_name = name;
    }

    public String getItem_desc() {
        return item_desc;
    }

    public void setItem_desc(String desc) {
        item_desc = desc;
    }

    public int getItem_qty() {
        return item_qty;
    }

    public void setItem_qty(int quantity) {
        item_qty = quantity;
    }
}
