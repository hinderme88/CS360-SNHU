package com.cs360.maryeakins_inventory.ui;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.View;
import android.widget.Switch;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.cs360.maryeakins_inventory.R;
import com.cs360.maryeakins_inventory.MyRecyclerViewAdapter;
import com.cs360.maryeakins_inventory.data.DatabaseHelper;
import com.cs360.maryeakins_inventory.model.Item;

import java.util.List;

public class GridActivity extends AppCompatActivity implements MyRecyclerViewAdapter.OnItemClickListener, MyRecyclerViewAdapter.OnItemDeleteListener {
    RecyclerView recyclerView;
    DatabaseHelper DB;
    MyRecyclerViewAdapter adapter;
    private Switch notifySwitch;
    private static final int PERMISSION_SEND_SMS = 123;
    private static final int LOW_INVENTORY_THRESHOLD = 5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grid);

        DB = new DatabaseHelper(this);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Create and set the RecyclerView adapter
        updateItemList();

        FloatingActionButton addButton = findViewById(R.id.add_new);

        // navigate to Add screen when Add button is pressed
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(GridActivity.this, AddActivity.class);
                startActivity(intent);
            }
        });
        // Initialize the Switch and set up the listener
        notifySwitch = findViewById(R.id.switch1);
        notifySwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                checkForPermission();
            }
        });

    }

    private void updateItemList() {
        List<Item> itemList = DB.getAllItems();
        if (adapter == null) {
            adapter = new MyRecyclerViewAdapter(itemList, this, this, this);
            recyclerView.setAdapter(adapter);
        } else {
            adapter = new MyRecyclerViewAdapter(itemList, this, this, this);
            recyclerView.swapAdapter(adapter, false);
        }
    }

    // navigate to Update screen when item in recyclerview is clicked
    @Override
    public void onItemClick(Item item) {
        Intent intent = new Intent(GridActivity.this, UpdateActivity.class);
        intent.putExtra("ITEM_NAME", item.getItem_name());
        intent.putExtra("ITEM_DESC", item.getItem_desc());
        intent.putExtra("ITEM_QTY", item.getItem_qty());
        startActivity(intent);

    }

    @Override
    public void onItemDelete(Item item, int position) {
        // delete item using DatabaseHelper
        DB.deleteItem(item);
        // remove from the adapter
        adapter.removeItem(position);
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateItemList();
        checkStockLevels();
    }

    private void checkStockLevels() {
        List<Item> itemList = DB.getAllItems();
        for (Item item : itemList) {
            if (item.getItem_qty() <= LOW_INVENTORY_THRESHOLD) {
                sendLowInventorySms(item);
            }
        }
    }
    private void checkForPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, PERMISSION_SEND_SMS);
        } else {
            sendMessage();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_SEND_SMS) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                sendMessage();
            }
        }
    }

    private void sendLowInventorySms(Item item) {
        // Only attempt to send an SMS if the switch is on
        if (notifySwitch.isChecked()) {
            String phoneNumber = "1234567890";
            String message = "Alert: low stock for " + item.getItem_name() + "! Just " + item.getItem_qty() + " left in stock.";

            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, PERMISSION_SEND_SMS);
            } else {
                try {
                    Context context = getApplicationContext();
                    SmsManager smsManager = context.getSystemService(SmsManager.class);
                    smsManager.sendTextMessage(phoneNumber, null, message, null, null);
                    Toast.makeText(context, "Alert: low stock for " + item.getItem_name() + "! Just " + item.getItem_qty() + " left in stock.", Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    Toast.makeText(getApplicationContext(), "Notification failed.", Toast.LENGTH_LONG).show();
                    e.printStackTrace();
                }
            }
        } else {
            // The switch is off, do not send SMS
            Toast.makeText(this, "SMS notification is disabled", Toast.LENGTH_SHORT).show();
        }
    }

    private void sendMessage() {
        String phoneNumber = "1234567890"; // Dummy number for testing
        String message = "This is a test SMS message.";

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            try {
                Context context = getApplicationContext();
                SmsManager smsManager = context.getSystemService(SmsManager.class);
                smsManager.sendTextMessage(phoneNumber, null, message, null, null);
                Toast.makeText(getApplicationContext(), "SMS sent.", Toast.LENGTH_LONG).show();
                Log.d("SMS_TEST", "SMS sent to " + phoneNumber + ": " + message);
            } catch (Exception e) {
                Toast.makeText(getApplicationContext(), "Sending SMS failed (simulated).", Toast.LENGTH_LONG).show();
                Log.e("SMS_TEST", "SMS sending failed", e);
            }
        } else {
            Log.d("SMS_TEST", "SMS permission not granted.");
            // Permission not granted, request it
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, PERMISSION_SEND_SMS);
        }
    }

}
