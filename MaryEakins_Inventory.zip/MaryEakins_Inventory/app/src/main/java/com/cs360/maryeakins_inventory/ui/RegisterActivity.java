package com.cs360.maryeakins_inventory.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.cs360.maryeakins_inventory.ui.GridActivity;
import com.cs360.maryeakins_inventory.ui.MainActivity;
import com.cs360.maryeakins_inventory.R;
import com.cs360.maryeakins_inventory.data.LoginHelper;

public class RegisterActivity extends AppCompatActivity {

    EditText userName, passWord, passWord2;

    Button buttonSignup, buttonExistingUser;

    LoginHelper DATABASE;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        userName = (EditText) findViewById(R.id.registerNameEdit);
        passWord = (EditText) findViewById(R.id.registerPasswordEdit);
        passWord2 = (EditText) findViewById(R.id.registerPassword2Edit);

        buttonSignup = (Button) findViewById(R.id.registerSignUpBtn);
        buttonExistingUser = (Button) findViewById(R.id.registerLoginBtn);

        DATABASE = new LoginHelper(this);

        // Handle Sign Up button events
        buttonSignup.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                String user = userName.getText().toString();
                String password = passWord.getText().toString();
                String password2 = passWord2.getText().toString();

                // Check to ensure no fields are empty
                if (user.equals("") || (password.equals("") || password2.equals("")))
                    Toast.makeText(RegisterActivity.this, "All fields are required.", Toast.LENGTH_SHORT).show();
                else {
                    // First check to make sure both passwords match
                    if (password.equals(password2)) {
                        // Next check to see if username already exists in database
                        Boolean checkUser = DATABASE.findUsername(user);
                        if (checkUser == false) {
                            // User doesnt exist, add them now
                            Boolean addUser = DATABASE.insertData(user, password);
                            if (addUser == true) {
                                // User was added, proceed to main page of app
                                Toast.makeText(RegisterActivity.this, "User was successfully registered!", Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(RegisterActivity.this, GridActivity.class);
                                startActivity(intent);
                            }
                        } else {
                            // Username is already in use
                            Toast.makeText(RegisterActivity.this, "This username already exists, please sign in.", Toast.LENGTH_SHORT).show();
                        }

                    } else {
                        // Passwords dont match
                        Toast.makeText(RegisterActivity.this, "Passwords must match.", Toast.LENGTH_SHORT).show();
                    }

                }
            }

        });

        // Handle Existing User button events
        buttonExistingUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(RegisterActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });


    }
}