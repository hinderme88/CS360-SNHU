package com.cs360.maryeakins_inventory.ui;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;
import com.cs360.maryeakins_inventory.model.Item;

import com.cs360.maryeakins_inventory.R;
import com.cs360.maryeakins_inventory.data.DatabaseHelper;

public class UpdateActivity extends AppCompatActivity {

    private EditText updateItemName, updateItemDesc, updateItemQty;

    private DatabaseHelper DB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update);

        DB = new DatabaseHelper(this);

        updateItemName = findViewById(R.id.updateNameEdit);
        updateItemDesc = findViewById(R.id.updateDescEdit);
        updateItemQty = findViewById(R.id.updateQtyEdit);

        Button updateButton = findViewById(R.id.updateItemButton);

        Intent intent = getIntent();

        loadItemData(intent);

        updateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                updateItem();
            }
        });
    }
    public void updateItem() {
        String itemName = updateItemName.getText().toString();
        String itemDesc = updateItemDesc.getText().toString();
        int itemQty = Integer.parseInt(updateItemQty.getText().toString());
        Item item = new Item(itemName, itemDesc, itemQty);
        DB.updateItem(item);
        finish();
    }
    private void loadItemData(Intent intent) {
        if (intent != null) {
            String itemName = intent.getStringExtra("ITEM_NAME");
            String itemDesc = intent.getStringExtra("ITEM_DESC");
            int itemQty = intent.getIntExtra("ITEM_QTY", -1);

            // Populate the fields
            updateItemName.setText(itemName);
            updateItemDesc.setText(itemDesc);
            if (itemQty != -1) {
                updateItemQty.setText(String.valueOf(itemQty));
            }
        }
    }

}