package com.cs360.maryeakins_inventory.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import androidx.annotation.Nullable;
import com.cs360.maryeakins_inventory.R;
import com.cs360.maryeakins_inventory.Util;
import com.cs360.maryeakins_inventory.model.Item;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    private Context context;
    public DatabaseHelper(@Nullable Context context) {
        super(context, Util.DATABASE_NAME, null, Util.DATABASE_VERSION);
        this.context = context;
    }

    @Override
    // CREATE TABLE items (id INTEGER PRIMARY KEY,item_name TEXT,item_desc TEXT,item_quantity INTEGER)
    public void onCreate(SQLiteDatabase appDatabase) {
        String CREATE_ITEM_TABLE = "CREATE TABLE " + Util.TABLE_NAME + " ("
                + Util.KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + Util.KEY_NAME + " TEXT, "
                + Util.KEY_DESC + " TEXT, "
                + Util.KEY_QTY + " INTEGER);";
        appDatabase.execSQL(CREATE_ITEM_TABLE);

    }

    @Override
    public void onUpgrade(SQLiteDatabase appDatabase, int oldVersion, int newVersion) {
        // Drop existing table
        appDatabase.execSQL("DROP TABLE IF EXISTS " + Util.TABLE_NAME);

        // Create a new table
        onCreate(appDatabase);
    }

    // Add an item to the database
    public boolean addItem(Item item) {
        SQLiteDatabase appDatabase = this.getWritableDatabase();

        ContentValues contentValues = new ContentValues();
        contentValues.put(Util.KEY_NAME, item.getItem_name());
        contentValues.put(Util.KEY_DESC, item.getItem_desc());
        contentValues.put(Util.KEY_QTY, item.getItem_qty());

        long result = appDatabase.insert(Util.TABLE_NAME, null, contentValues);
        //appDatabase.close();
        if (result == -1) return false;
        else
            return true;
    }
    // Update an item
    public int updateItem(Item item) {
        SQLiteDatabase appDatabase = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(Util.KEY_NAME, item.getItem_name());
        contentValues.put(Util.KEY_DESC, item.getItem_desc());
        contentValues.put(Util.KEY_QTY, item.getItem_qty());

        return appDatabase.update(Util.TABLE_NAME, contentValues,
                Util.KEY_NAME + " = ? ",
                new String[]{String.valueOf(item.getItem_name())});
    }
    // Return all items
    public List<Item> getAllItems() {

        List<Item> itemList = new ArrayList<>();
        String selectQuery = "SELECT * FROM " + Util.TABLE_NAME;

        SQLiteDatabase appDatabase = this.getWritableDatabase();
        Cursor cursor = appDatabase.rawQuery(selectQuery, null);

        if (cursor.moveToFirst()) {
            do {
                int itemNameIndex = cursor.getColumnIndex(Util.KEY_NAME);
                int itemDescIndex = cursor.getColumnIndex(Util.KEY_DESC);
                int itemQtyIndex = cursor.getColumnIndex(Util.KEY_QTY);

                if (itemNameIndex != -1 && itemDescIndex != -1 && itemQtyIndex != -1) {
                    String itemName = cursor.getString(itemNameIndex);
                    String itemDesc = cursor.getString(itemDescIndex);
                    int itemQty = cursor.getInt(itemQtyIndex);

                    Item item = new Item(itemName, itemDesc, itemQty);
                    itemList.add(item);
                }
            } while (cursor.moveToNext());
        }
        cursor.close();

        return itemList;
    }

    // Delete an item
    public void deleteItem(Item item) {
        SQLiteDatabase appDatabase = this.getWritableDatabase();
        appDatabase.delete(Util.TABLE_NAME, Util.KEY_NAME + " = ? ", new String[] {item.getItem_name()});
        appDatabase.close();

    }

    // Check to avoid duplicate items
    public boolean checkItemUnique(String itemName) {
        SQLiteDatabase appDatabase = this.getReadableDatabase();

        Cursor cursor = appDatabase.query(Util.TABLE_NAME,
                new String[]{Util.KEY_NAME},
                Util.KEY_NAME + " = ? ",
                new String[]{itemName}, null, null, null);
        boolean itemExists = (cursor.getCount() > 0);
        cursor.close();
        return itemExists;
    }
}
